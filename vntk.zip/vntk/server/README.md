# NLP API Server

You can easily create a NLP API Server using `Vntk`. What you need to do is decide where to deploy server. Here are some helpful ways to do this.


## NPM Script

At the project directory, run:

* `$ npm start`

Then open your browser or `Postman` to test apis.

* http://localhost:3000/api/tok/xin%20chào%20các%20bạn
* http://localhost:3000/api/pos/xin%20chào%20các%20bạn
* http://localhost:3000/api/chunking/xin%20chào%20các%20bạn
* http://localhost:3000/api/ner/xin%20chào%20các%20bạn

## Docker
