// Vntk files are in the lib folder
module.exports = require('./lib/vntk');
